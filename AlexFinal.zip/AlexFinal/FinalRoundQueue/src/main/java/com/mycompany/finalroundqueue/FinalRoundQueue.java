

package com.mycompany.finalroundqueue;


public class FinalRoundQueue {

    public static void main(String[] args) {
        
        
        
//        RoundFIFOQueue<Integer> fifo = new RoundFIFOQueue(4, new Integer[0]);
////       fifo.printQueue();
//       fifo.enqueue(1, true);
//       fifo.enqueue(2, true);
//       fifo.enqueue(3, true);
//       fifo.enqueue(4, true);
//       fifo.enqueue(5, true);
//       fifo.enqueue(6, true);
//       fifo.enqueue(7, true);
//       fifo.enqueue(8, true);
     
//       fifo.printQueue();
//       Integer[] theArr = fifo.toArray();
//     
//       System.out.println(fifo.countValues(6));
//
//       
//       System.out.println("the array");
//       for (Integer num : theArr){
//           System.out.println(num);
//       }
//        System.out.println("the iterator");
//       for (Integer num : fifo){
//           System.out.println(num);
//       }
//       

    }
}
